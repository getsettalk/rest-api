<?php
namespace api\controllers;

class PostController {
 

    public static function getPosts() {
        // Handle the logic to get posts data and return JSON response
        echo "get post";
    }
}
